import ecdsa
import hashlib

# Step 1: Generate a private key
private_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
# Get the associated public key
public_key = private_key.get_verifying_key()

# Step 2: Sign a message
# Input the message to be signed from the keyboard
message = input("Enter the message to sign: ").encode()
# Hash the message using SHA-256
message_hash = hashlib.sha256(message).digest()
# Sign the hash of the message
signature = private_key.sign(message_hash)
print("Message signed.")

# Print the signature in hexadecimal format
print("Signature (in hex):", signature.hex())

# Step 3: Verify the signature
# Input the check message from the keyboard
message_check = input("Enter the message to verify: ").encode()
# Hash the check message using SHA-256
message_check_hash = hashlib.sha256(message_check).digest()

try:
    # Verify the signature using the public key
    public_key.verify(signature, message_check_hash)
    print("Signature is valid.")
except ecdsa.BadSignatureError:
    print("Signature is invalid.")

# Optional: Print the private and public keys in hex format
print("Private key:", private_key.to_string().hex())
print("Public key:", public_key.to_string().hex())

