import ecdsa
import hashlib

# Load the signature, private key, and public key from files

# Step 3: Verify the signature
# Input the check message from the keyboard
message_check = input("Enter the message to verify: ").encode()
# Hash the check message using SHA-256
message_check_hash = hashlib.sha256(message_check).digest()

try:
    # Verify the signature using the public key
    public_key.verify(signature, message_check_hash)
    print("Signature is valid.")
except ecdsa.BadSignatureError:
    print("Signature is invalid.")

