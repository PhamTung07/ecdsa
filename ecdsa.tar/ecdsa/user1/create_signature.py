import ecdsa
import hashlib

# Step 1: Generate a private key
private_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
# Get the associated public key
public_key = private_key.get_verifying_key()

# Step 2: Sign a message
# Input the message to be signed from the keyboard
# Hash the message using SHA-256
message_hash = hashlib.sha256(message).digest()
# Sign the hash of the message
signature = private_key.sign(message_hash)
print("Message signed.")

# Print the signature in hexadecimal format
print("Signature (in hex):", signature.hex())

# Optional: Print the private and public keys in hex format
print("Private key:", private_key.to_string().hex())
print("Public key:", public_key.to_string().hex())

# Save the signature, private key, and public key to files for later use

